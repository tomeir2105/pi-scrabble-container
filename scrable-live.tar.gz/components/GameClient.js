"use client";

import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { io } from "socket.io-client";
import { BOARD_PREMIUMS, BOARD_SIZE, PREMIUM_LABELS } from "@/lib/constants";

const COLUMN_LABELS = "ABCDEFGHIJKLMNO".split("");

function emitWithAck(socket, event, payload) {
  return new Promise((resolve) => {
    socket.emit(event, payload, (response) => resolve(response));
  });
}

function formatError(message) {
  if (!message) {
    return "Something went wrong.";
  }
  return message;
}

export default function GameClient() {
  const searchParams = useSearchParams();
  const initialRoomCode = (searchParams.get("room") || "").toUpperCase();
  const socketRef = useRef(null);
  const autoJoinAttemptedRef = useRef(false);

  const [playerId, setPlayerId] = useState("");
  const [playerName, setPlayerName] = useState("");
  const [roomCodeInput, setRoomCodeInput] = useState(initialRoomCode);
  const [roomState, setRoomState] = useState(null);
  const [connected, setConnected] = useState(false);
  const [feedback, setFeedback] = useState("Create a room or join one from your phone.");
  const [busy, setBusy] = useState(false);
  const [selectedTileId, setSelectedTileId] = useState(null);
  const [pendingPlacements, setPendingPlacements] = useState([]);
  const [exchangeMode, setExchangeMode] = useState(false);
  const [exchangeTileIds, setExchangeTileIds] = useState([]);

  const selfPlayer = roomState?.players.find((player) => player.id === playerId) || null;
  const isMyTurn = roomState?.currentTurnPlayerId === playerId;
  const pendingBySquare = new Map(pendingPlacements.map((placement) => [`${placement.row}:${placement.column}`, placement]));
  const pendingByTileId = new Map(pendingPlacements.map((placement) => [placement.tileId, placement]));

  useEffect(() => {
    const savedPlayerId = window.localStorage.getItem("scrable-player-id");
    const nextPlayerId = savedPlayerId || globalThis.crypto.randomUUID();
    const savedPlayerName = window.localStorage.getItem("scrable-player-name") || "";
    window.localStorage.setItem("scrable-player-id", nextPlayerId);
    setPlayerId(nextPlayerId);
    setPlayerName(savedPlayerName);
  }, []);

  useEffect(() => {
    const socket = io({
      transports: ["websocket", "polling"]
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      setFeedback((current) =>
        current === "Connection lost. Trying to reconnect..." ? "Reconnected." : current || "Connected."
      );
    });

    socket.on("disconnect", () => {
      setConnected(false);
      setFeedback("Connection lost. Trying to reconnect...");
    });

    socket.on("room:state", (nextRoomState) => {
      setRoomState(nextRoomState);
    });

    return () => {
      socket.close();
      socketRef.current = null;
    };
  }, []);

  useEffect(() => {
    setRoomCodeInput(initialRoomCode);
  }, [initialRoomCode]);

  useEffect(() => {
    if (!selfPlayer) {
      return;
    }

    const rackIds = new Set(selfPlayer.rack.map((tile) => tile.id));
    setPendingPlacements((current) => current.filter((placement) => rackIds.has(placement.tileId)));
    setExchangeTileIds((current) => current.filter((tileId) => rackIds.has(tileId)));

    if (selectedTileId && !rackIds.has(selectedTileId)) {
      setSelectedTileId(null);
    }
  }, [roomState, selfPlayer, selectedTileId]);

  useEffect(() => {
    if (!connected || !playerId || !playerName.trim() || !initialRoomCode || autoJoinAttemptedRef.current || roomState) {
      return;
    }

    autoJoinAttemptedRef.current = true;
    joinRoom(initialRoomCode);
  }, [connected, initialRoomCode, playerId, playerName, roomState]);

  async function createRoom() {
    if (!socketRef.current) {
      return;
    }

    const trimmedName = playerName.trim();
    if (!trimmedName) {
      setFeedback("Choose a player name first.");
      return;
    }

    window.localStorage.setItem("scrable-player-name", trimmedName);
    setBusy(true);
    setFeedback("Creating room...");
    const response = await emitWithAck(socketRef.current, "room:create", {
      name: trimmedName,
      playerId
    });
    setBusy(false);

    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }

    window.history.replaceState({}, "", `?room=${response.roomId}`);
    setRoomCodeInput(response.roomId);
    setFeedback(`Room ${response.roomId} is ready. Share the link and start when everyone joins.`);
  }

  async function joinRoom(overrideRoomCode) {
    if (!socketRef.current) {
      return;
    }

    const trimmedName = playerName.trim();
    const nextRoomCode = (overrideRoomCode || roomCodeInput).toUpperCase().trim();
    if (!trimmedName) {
      setFeedback("Choose a player name first.");
      return;
    }
    if (!nextRoomCode) {
      setFeedback("Enter a room code.");
      return;
    }

    window.localStorage.setItem("scrable-player-name", trimmedName);
    setBusy(true);
    setFeedback(`Joining room ${nextRoomCode}...`);
    const response = await emitWithAck(socketRef.current, "room:join", {
      roomId: nextRoomCode,
      name: trimmedName,
      playerId
    });
    setBusy(false);

    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }

    window.history.replaceState({}, "", `?room=${response.roomId}`);
    setRoomCodeInput(response.roomId);
    setFeedback(`Joined room ${response.roomId}.`);
  }

  async function startGame() {
    if (!socketRef.current) {
      return;
    }

    setBusy(true);
    const response = await emitWithAck(socketRef.current, "game:start");
    setBusy(false);
    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }
    setFeedback("Game started.");
  }

  async function submitMove() {
    if (!socketRef.current || pendingPlacements.length === 0) {
      return;
    }

    setBusy(true);
    const response = await emitWithAck(socketRef.current, "game:play", {
      placements: pendingPlacements
    });
    setBusy(false);

    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }

    setPendingPlacements([]);
    setSelectedTileId(null);
    setExchangeMode(false);
    setExchangeTileIds([]);
    setFeedback("Move submitted.");
  }

  async function passMove() {
    if (!socketRef.current) {
      return;
    }

    setBusy(true);
    const response = await emitWithAck(socketRef.current, "game:pass");
    setBusy(false);
    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }

    setPendingPlacements([]);
    setSelectedTileId(null);
    setExchangeMode(false);
    setExchangeTileIds([]);
    setFeedback("Turn passed.");
  }

  async function exchangeTiles() {
    if (!socketRef.current || exchangeTileIds.length === 0) {
      return;
    }

    setBusy(true);
    const response = await emitWithAck(socketRef.current, "game:exchange", {
      tileIds: exchangeTileIds
    });
    setBusy(false);
    if (!response?.ok) {
      setFeedback(formatError(response?.error));
      return;
    }

    setPendingPlacements([]);
    setSelectedTileId(null);
    setExchangeMode(false);
    setExchangeTileIds([]);
    setFeedback("Tiles exchanged.");
  }

  function toggleExchangeTile(tileId) {
    setExchangeTileIds((current) =>
      current.includes(tileId) ? current.filter((candidate) => candidate !== tileId) : [...current, tileId]
    );
  }

  function handleRackTileClick(tileId) {
    if (!selfPlayer || !isMyTurn || roomState?.finished) {
      return;
    }

    if (exchangeMode) {
      toggleExchangeTile(tileId);
      return;
    }

    const existingPlacement = pendingByTileId.get(tileId);
    if (existingPlacement) {
      setPendingPlacements((current) => current.filter((placement) => placement.tileId !== tileId));
      setSelectedTileId(tileId);
      return;
    }

    setSelectedTileId((current) => (current === tileId ? null : tileId));
  }

  function handleBoardClick(row, column) {
    if (!selfPlayer || !roomState?.started || !isMyTurn || roomState.finished || exchangeMode) {
      return;
    }

    const lockedCell = roomState.board[row][column];
    if (lockedCell) {
      return;
    }

    const existingPlacement = pendingBySquare.get(`${row}:${column}`);
    if (existingPlacement) {
      setPendingPlacements((current) => current.filter((placement) => placement.tileId !== existingPlacement.tileId));
      setSelectedTileId(existingPlacement.tileId);
      return;
    }

    if (!selectedTileId) {
      setFeedback("Select a tile from your rack, then tap a square.");
      return;
    }

    setPendingPlacements((current) => {
      const withoutTile = current.filter((placement) => placement.tileId !== selectedTileId);
      return [...withoutTile, { tileId: selectedTileId, row, column }];
    });
    setSelectedTileId(null);
  }

  function recallTiles() {
    setPendingPlacements([]);
    setSelectedTileId(null);
  }

  async function copyInviteLink() {
    if (!roomState?.id) {
      return;
    }

    const inviteLink = `${window.location.origin}?room=${roomState.id}`;
    await navigator.clipboard.writeText(inviteLink);
    setFeedback("Invite link copied.");
  }

  function renderLanding() {
    return (
      <section className="shell">
        <div className="hero-card">
          <div className="eyebrow">Realtime multiplayer word game</div>
          <h1>Scrable Live</h1>
          <p className="hero-copy">
            Create a room, share the link, and let everyone join from their phones to play on one shared board.
          </p>

          <div className="panel-grid">
            <div className="panel">
              <label className="field-label" htmlFor="playerName">
                Your name
              </label>
              <input
                id="playerName"
                className="text-input"
                value={playerName}
                maxLength={24}
                onChange={(event) => setPlayerName(event.target.value)}
                placeholder="Nina"
              />
              <div className="actions">
                <button className="primary-button" disabled={busy || !connected} onClick={createRoom}>
                  Create Room
                </button>
              </div>
            </div>

            <div className="panel">
              <label className="field-label" htmlFor="roomCode">
                Join room
              </label>
              <input
                id="roomCode"
                className="text-input"
                value={roomCodeInput}
                maxLength={5}
                onChange={(event) => setRoomCodeInput(event.target.value.toUpperCase())}
                placeholder="AB123"
              />
              <div className="actions">
                <button className="secondary-button" disabled={busy || !connected} onClick={() => joinRoom()}>
                  Join Room
                </button>
              </div>
            </div>
          </div>

          <div className="status-banner">{feedback}</div>

          <div className="assumption-card">
            <strong>Default setup:</strong> 15x15 board, English tile values, room-based multiplayer, standard-style letter and word bonuses.
          </div>
        </div>
      </section>
    );
  }

  if (!roomState) {
    return renderLanding();
  }

  const winnerNames = roomState.winnerIds
    .map((winnerId) => roomState.players.find((player) => player.id === winnerId)?.name)
    .filter(Boolean)
    .join(", ");

  return (
    <main className="game-shell">
      <section className="topbar">
        <div>
          <div className="eyebrow">Room {roomState.id}</div>
          <h1>Scrable Live</h1>
          <p className="hero-copy">
            {roomState.started
              ? roomState.finished
                ? `Game over${winnerNames ? `: ${winnerNames}` : ""}.`
                : isMyTurn
                  ? "Your turn."
                  : `${roomState.players.find((player) => player.id === roomState.currentTurnPlayerId)?.name || "Another player"} is up.`
              : "Waiting in the lobby."}
          </p>
        </div>
        <div className="invite-box">
          <div className="status-chip">{connected ? "Online" : "Reconnecting"}</div>
          <button className="ghost-button" onClick={copyInviteLink}>
            Copy Invite Link
          </button>
        </div>
      </section>

      <section className="panel-grid game-layout">
        <div className="panel board-panel">
          <div className="board-scroll">
            <div className="board-header-row">
              <div className="corner-spacer" />
              {COLUMN_LABELS.map((label) => (
                <div className="axis-label" key={label}>
                  {label}
                </div>
              ))}
            </div>

            {Array.from({ length: BOARD_SIZE }, (_, row) => (
              <div className="board-row" key={`row-${row}`}>
                <div className="axis-label">{row + 1}</div>
                {Array.from({ length: BOARD_SIZE }, (_, column) => {
                  const lockedCell = roomState.board[row][column];
                  const pendingCell = pendingBySquare.get(`${row}:${column}`);
                  const premium = BOARD_PREMIUMS[row][column];
                  const tile = pendingCell || lockedCell;
                  const premiumLabel = PREMIUM_LABELS[premium];
                  const isSelectedPlacement = pendingCell?.tileId === selectedTileId;

                  return (
                    <button
                      key={`${row}-${column}`}
                      className={[
                        "board-cell",
                        `premium-${premium.toLowerCase()}`,
                        tile ? "filled" : "",
                        pendingCell ? "pending" : "",
                        isSelectedPlacement ? "selected" : ""
                      ]
                        .filter(Boolean)
                        .join(" ")}
                      onClick={() => handleBoardClick(row, column)}
                      title={tile ? tile.letter : premiumLabel || "Board square"}
                    >
                      {tile ? (
                        <>
                          <span className="tile-letter">{tile.letter}</span>
                          <span className="tile-score">{tile.value}</span>
                        </>
                      ) : (
                        <span className="premium-text">{premium === "__" ? "" : premium}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        <div className="sidebar">
          <div className="panel">
            <div className="panel-title">Players</div>
            <div className="player-list">
              {roomState.players.map((player) => (
                <div
                  className={[
                    "player-card",
                    player.id === roomState.currentTurnPlayerId && !roomState.finished ? "active" : "",
                    player.id === playerId ? "self" : ""
                  ]
                    .filter(Boolean)
                    .join(" ")}
                  key={player.id}
                >
                  <div>
                    <strong>{player.name}</strong>
                    <div className="player-meta">
                      {player.connected ? "Connected" : "Offline"} - {player.rackCount} tiles
                    </div>
                  </div>
                  <div className="player-score">{player.score}</div>
                </div>
              ))}
            </div>

            {!roomState.started && selfPlayer?.isHost ? (
              <div className="actions">
                <button className="primary-button" disabled={busy || roomState.players.length < 2} onClick={startGame}>
                  Start Game
                </button>
              </div>
            ) : null}
          </div>

          <div className="panel">
            <div className="panel-title">Rack</div>
            <div className="rack">
              {selfPlayer?.rack.map((tile) => {
                const placed = pendingByTileId.has(tile.id);
                const selected = selectedTileId === tile.id;
                const markedForExchange = exchangeTileIds.includes(tile.id);

                return (
                  <button
                    key={tile.id}
                    className={[
                      "rack-tile",
                      selected ? "selected" : "",
                      placed ? "placed" : "",
                      markedForExchange ? "exchange" : ""
                    ]
                      .filter(Boolean)
                      .join(" ")}
                    onClick={() => handleRackTileClick(tile.id)}
                  >
                    <span className="tile-letter">{tile.letter}</span>
                    <span className="tile-score">{tile.value}</span>
                  </button>
                );
              })}
            </div>

            {roomState.started ? (
              <>
                <div className="turn-tools">
                  <button
                    className={exchangeMode ? "secondary-button active-button" : "secondary-button"}
                    disabled={busy || !isMyTurn || roomState.finished}
                    onClick={() => {
                      setExchangeMode((current) => !current);
                      setExchangeTileIds([]);
                      setSelectedTileId(null);
                      setPendingPlacements([]);
                    }}
                  >
                    {exchangeMode ? "Cancel Exchange" : "Exchange Mode"}
                  </button>
                  <button className="ghost-button" disabled={busy || pendingPlacements.length === 0} onClick={recallTiles}>
                    Recall Tiles
                  </button>
                </div>

                <div className="actions">
                  {!exchangeMode ? (
                    <>
                      <button className="primary-button" disabled={busy || !isMyTurn || pendingPlacements.length === 0 || roomState.finished} onClick={submitMove}>
                        Submit Move
                      </button>
                      <button className="secondary-button" disabled={busy || !isMyTurn || roomState.finished} onClick={passMove}>
                        Pass
                      </button>
                    </>
                  ) : (
                    <button
                      className="primary-button"
                      disabled={busy || !isMyTurn || exchangeTileIds.length === 0 || roomState.finished}
                      onClick={exchangeTiles}
                    >
                      Exchange {exchangeTileIds.length || ""}
                    </button>
                  )}
                </div>
              </>
            ) : (
              <p className="hint-text">The rack will fill automatically when the host starts the game.</p>
            )}
          </div>

          <div className="panel">
            <div className="panel-title">Match status</div>
            <div className="stat-line">
              <span>Tiles left</span>
              <strong>{roomState.bagCount}</strong>
            </div>
            <div className="stat-line">
              <span>Last action</span>
              <strong>{roomState.lastAction || "No moves yet."}</strong>
            </div>
            <div className="stat-line">
              <span>Last words</span>
              <strong>{roomState.lastWords.length ? roomState.lastWords.join(", ") : "None"}</strong>
            </div>
            <div className="stat-line">
              <span>Last score</span>
              <strong>{roomState.lastScore}</strong>
            </div>
            <div className="status-banner compact">{feedback}</div>
          </div>
        </div>
      </section>
    </main>
  );
}
