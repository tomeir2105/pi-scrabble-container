import fs from "node:fs";
import http from "node:http";
import next from "next";
import { Server } from "socket.io";
import {
  addPlayerToRoom,
  attachSocketToPlayer,
  createRoom,
  createRoomCode,
  detachSocket,
  exchangeTiles,
  passTurn,
  playMove,
  serializeRoomForPlayer,
  startGame
} from "./lib/game.js";

const dev = process.env.NODE_ENV !== "production";
const hostname = "0.0.0.0";
const port = Number(process.env.PORT || 3010);
const nextApp = next({ dev, hostname, port });
const handle = nextApp.getRequestHandler();
const rooms = new Map();

function normalizeName(value) {
  const cleaned = String(value || "")
    .trim()
    .replace(/\s+/g, " ")
    .slice(0, 24);
  return cleaned || "Player";
}

function normalizeRoomCode(value) {
  return String(value || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 5);
}

function normalizePlayerId(value) {
  const cleaned = String(value || "").trim().slice(0, 80);
  if (!cleaned) {
    throw new Error("A valid player session is required.");
  }
  return cleaned;
}

async function loadDictionary() {
  try {
    const { default: wordListPath } = await import("word-list");
    const file = fs.readFileSync(wordListPath, "utf8");
    return new Set(
      file
        .split("\n")
        .map((entry) => entry.trim().toLowerCase())
        .filter(Boolean)
    );
  } catch (error) {
    console.warn("Dictionary load failed. Falling back to open word validation.", error);
    return new Set();
  }
}

function getRoom(roomId) {
  const room = rooms.get(roomId);
  if (!room) {
    throw new Error("Room not found.");
  }
  return room;
}

function maybeDeleteRoom(room) {
  if (!room) {
    return;
  }
  const hasConnectedPlayer = room.players.some((player) => player.connected);
  if (!hasConnectedPlayer && !room.started) {
    rooms.delete(room.id);
  }
}

function emitRoomState(io, room) {
  room.players.forEach((player) => {
    if (!player.socketId) {
      return;
    }
    io.to(player.socketId).emit("room:state", serializeRoomForPlayer(room, player.id));
  });
}

function leaveExistingRoom(io, socket) {
  const previousRoomId = socket.data.roomId;
  if (!previousRoomId) {
    return;
  }

  socket.leave(previousRoomId);
  const room = rooms.get(previousRoomId);
  if (!room) {
    socket.data.roomId = null;
    socket.data.playerId = null;
    return;
  }

  detachSocket(room, socket.id);
  socket.data.roomId = null;
  socket.data.playerId = null;
  emitRoomState(io, room);
  maybeDeleteRoom(room);
}

const dictionary = await loadDictionary();

nextApp.prepare().then(() => {
  const server = http.createServer((request, response) => handle(request, response));
  const io = new Server(server, {
    cors: {
      origin: "*"
    }
  });

  io.on("connection", (socket) => {
    socket.data.roomId = null;
    socket.data.playerId = null;

    socket.on("room:create", (payload, respond = () => {}) => {
      try {
        leaveExistingRoom(io, socket);
        const playerName = normalizeName(payload?.name);
        const playerId = normalizePlayerId(payload?.playerId);
        const roomId = createRoomCode(new Set(rooms.keys()));
        const room = createRoom({ roomId, playerId, playerName });
        rooms.set(roomId, room);
        attachSocketToPlayer(room, playerId, socket.id);
        socket.data.roomId = roomId;
        socket.data.playerId = playerId;
        socket.join(roomId);
        emitRoomState(io, room);
        respond({ ok: true, roomId });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("room:join", (payload, respond = () => {}) => {
      try {
        leaveExistingRoom(io, socket);
        const roomId = normalizeRoomCode(payload?.roomId);
        const playerName = normalizeName(payload?.name);
        const playerId = normalizePlayerId(payload?.playerId);
        const room = getRoom(roomId);
        addPlayerToRoom(room, { playerId, playerName });
        attachSocketToPlayer(room, playerId, socket.id);
        socket.data.roomId = roomId;
        socket.data.playerId = playerId;
        socket.join(roomId);
        emitRoomState(io, room);
        respond({ ok: true, roomId });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("game:start", (_, respond = () => {}) => {
      try {
        const room = getRoom(socket.data.roomId);
        startGame(room, socket.data.playerId);
        emitRoomState(io, room);
        respond({ ok: true });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("game:play", (payload, respond = () => {}) => {
      try {
        const room = getRoom(socket.data.roomId);
        playMove(room, socket.data.playerId, payload?.placements, { dictionary });
        emitRoomState(io, room);
        respond({ ok: true });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("game:pass", (_, respond = () => {}) => {
      try {
        const room = getRoom(socket.data.roomId);
        passTurn(room, socket.data.playerId);
        emitRoomState(io, room);
        respond({ ok: true });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("game:exchange", (payload, respond = () => {}) => {
      try {
        const room = getRoom(socket.data.roomId);
        exchangeTiles(room, socket.data.playerId, payload?.tileIds);
        emitRoomState(io, room);
        respond({ ok: true });
      } catch (error) {
        respond({ ok: false, error: error.message });
      }
    });

    socket.on("disconnect", () => {
      const room = rooms.get(socket.data.roomId);
      if (!room) {
        return;
      }
      detachSocket(room, socket.id);
      emitRoomState(io, room);
      maybeDeleteRoom(room);
    });
  });

  server.listen(port, hostname, () => {
    console.log(`Scrable Live running on http://${hostname}:${port}`);
  });
});
